package com.shad.SpringMvc;

import org.springframework.stereotype.Component;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Component
@EnableSwagger2
public class SwaggerConfig {
	
	// URL: http://localhost:9090/swagger-ui

}
